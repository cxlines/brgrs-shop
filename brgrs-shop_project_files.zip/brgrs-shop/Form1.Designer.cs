﻿namespace brgrs_shop
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.headerpnl = new System.Windows.Forms.Panel();
            this.exitlbl = new System.Windows.Forms.Label();
            this.headerlink = new System.Windows.Forms.Label();
            this.headerlogo = new System.Windows.Forms.Panel();
            this.hamburger = new System.Windows.Forms.Panel();
            this.cheeseb = new System.Windows.Forms.Panel();
            this.fries = new System.Windows.Forms.Panel();
            this.hotdog = new System.Windows.Forms.Panel();
            this.canadadd = new System.Windows.Forms.Panel();
            this.waterb = new System.Windows.Forms.Panel();
            this.colas = new System.Windows.Forms.Panel();
            this.sprite = new System.Windows.Forms.Panel();
            this.fantas = new System.Windows.Forms.Panel();
            this.paymentlbl = new System.Windows.Forms.Label();
            this.recieptslbl = new System.Windows.Forms.Label();
            this.acceptbtn = new System.Windows.Forms.Button();
            this.headerpnl.SuspendLayout();
            this.SuspendLayout();
            // 
            // headerpnl
            // 
            this.headerpnl.BackColor = System.Drawing.Color.Black;
            this.headerpnl.Controls.Add(this.exitlbl);
            this.headerpnl.Controls.Add(this.headerlink);
            this.headerpnl.Controls.Add(this.headerlogo);
            this.headerpnl.Dock = System.Windows.Forms.DockStyle.Top;
            this.headerpnl.Location = new System.Drawing.Point(0, 0);
            this.headerpnl.Name = "headerpnl";
            this.headerpnl.Size = new System.Drawing.Size(982, 74);
            this.headerpnl.TabIndex = 0;
            // 
            // exitlbl
            // 
            this.exitlbl.AutoSize = true;
            this.exitlbl.Font = new System.Drawing.Font("Yu Gothic Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.exitlbl.Location = new System.Drawing.Point(923, 21);
            this.exitlbl.Name = "exitlbl";
            this.exitlbl.Size = new System.Drawing.Size(47, 39);
            this.exitlbl.TabIndex = 2;
            this.exitlbl.Text = "→";
            this.exitlbl.Click += new System.EventHandler(this.exitlbl_Click);
            // 
            // headerlink
            // 
            this.headerlink.AutoSize = true;
            this.headerlink.Font = new System.Drawing.Font("Yu Gothic Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.headerlink.Location = new System.Drawing.Point(86, 21);
            this.headerlink.Name = "headerlink";
            this.headerlink.Size = new System.Drawing.Size(202, 39);
            this.headerlink.TabIndex = 1;
            this.headerlink.Text = "BRGRS SHOP";
            this.headerlink.Click += new System.EventHandler(this.headerlink_Click);
            // 
            // headerlogo
            // 
            this.headerlogo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("headerlogo.BackgroundImage")));
            this.headerlogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.headerlogo.Location = new System.Drawing.Point(3, 4);
            this.headerlogo.Name = "headerlogo";
            this.headerlogo.Size = new System.Drawing.Size(77, 67);
            this.headerlogo.TabIndex = 1;
            this.headerlogo.Click += new System.EventHandler(this.headerlink_Click);
            // 
            // hamburger
            // 
            this.hamburger.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("hamburger.BackgroundImage")));
            this.hamburger.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hamburger.Location = new System.Drawing.Point(12, 80);
            this.hamburger.Name = "hamburger";
            this.hamburger.Size = new System.Drawing.Size(135, 118);
            this.hamburger.TabIndex = 1;
            this.hamburger.Click += new System.EventHandler(this.hamburger_Click);
            // 
            // cheeseb
            // 
            this.cheeseb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cheeseb.BackgroundImage")));
            this.cheeseb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cheeseb.Location = new System.Drawing.Point(153, 80);
            this.cheeseb.Name = "cheeseb";
            this.cheeseb.Size = new System.Drawing.Size(135, 118);
            this.cheeseb.TabIndex = 2;
            this.cheeseb.Click += new System.EventHandler(this.cheeseb_Click);
            // 
            // fries
            // 
            this.fries.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("fries.BackgroundImage")));
            this.fries.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.fries.Location = new System.Drawing.Point(294, 80);
            this.fries.Name = "fries";
            this.fries.Size = new System.Drawing.Size(150, 118);
            this.fries.TabIndex = 2;
            this.fries.Click += new System.EventHandler(this.fries_Click);
            // 
            // hotdog
            // 
            this.hotdog.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("hotdog.BackgroundImage")));
            this.hotdog.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hotdog.Location = new System.Drawing.Point(12, 204);
            this.hotdog.Name = "hotdog";
            this.hotdog.Size = new System.Drawing.Size(135, 118);
            this.hotdog.TabIndex = 2;
            this.hotdog.Click += new System.EventHandler(this.hotdog_Click);
            // 
            // canadadd
            // 
            this.canadadd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("canadadd.BackgroundImage")));
            this.canadadd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.canadadd.Location = new System.Drawing.Point(153, 204);
            this.canadadd.Name = "canadadd";
            this.canadadd.Size = new System.Drawing.Size(135, 118);
            this.canadadd.TabIndex = 2;
            this.canadadd.Click += new System.EventHandler(this.canadadd_Click);
            // 
            // waterb
            // 
            this.waterb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("waterb.BackgroundImage")));
            this.waterb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.waterb.Location = new System.Drawing.Point(294, 204);
            this.waterb.Name = "waterb";
            this.waterb.Size = new System.Drawing.Size(150, 118);
            this.waterb.TabIndex = 2;
            this.waterb.Click += new System.EventHandler(this.waterb_Click);
            // 
            // colas
            // 
            this.colas.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("colas.BackgroundImage")));
            this.colas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.colas.Location = new System.Drawing.Point(12, 328);
            this.colas.Name = "colas";
            this.colas.Size = new System.Drawing.Size(123, 118);
            this.colas.TabIndex = 2;
            this.colas.Click += new System.EventHandler(this.colas_Click);
            // 
            // sprite
            // 
            this.sprite.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sprite.BackgroundImage")));
            this.sprite.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sprite.Location = new System.Drawing.Point(141, 328);
            this.sprite.Name = "sprite";
            this.sprite.Size = new System.Drawing.Size(105, 118);
            this.sprite.TabIndex = 3;
            this.sprite.Click += new System.EventHandler(this.sprite_Click);
            // 
            // fantas
            // 
            this.fantas.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("fantas.BackgroundImage")));
            this.fantas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.fantas.Location = new System.Drawing.Point(252, 328);
            this.fantas.Name = "fantas";
            this.fantas.Size = new System.Drawing.Size(192, 118);
            this.fantas.TabIndex = 3;
            this.fantas.Click += new System.EventHandler(this.fantas_Click);
            // 
            // paymentlbl
            // 
            this.paymentlbl.AutoSize = true;
            this.paymentlbl.Font = new System.Drawing.Font("Yu Gothic Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.paymentlbl.Location = new System.Drawing.Point(450, 80);
            this.paymentlbl.Name = "paymentlbl";
            this.paymentlbl.Size = new System.Drawing.Size(234, 39);
            this.paymentlbl.TabIndex = 4;
            this.paymentlbl.Text = "PAYMENT IN $$";
            // 
            // recieptslbl
            // 
            this.recieptslbl.AutoSize = true;
            this.recieptslbl.Font = new System.Drawing.Font("Yu Gothic Light", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.recieptslbl.Location = new System.Drawing.Point(450, 119);
            this.recieptslbl.Name = "recieptslbl";
            this.recieptslbl.Size = new System.Drawing.Size(174, 35);
            this.recieptslbl.TabIndex = 5;
            this.recieptslbl.Text = "Reciept: >>>";
            // 
            // acceptbtn
            // 
            this.acceptbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.acceptbtn.Location = new System.Drawing.Point(841, 407);
            this.acceptbtn.Name = "acceptbtn";
            this.acceptbtn.Size = new System.Drawing.Size(129, 44);
            this.acceptbtn.TabIndex = 6;
            this.acceptbtn.Text = "Accept";
            this.acceptbtn.UseVisualStyleBackColor = true;
            this.acceptbtn.Click += new System.EventHandler(this.acceptbtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.ClientSize = new System.Drawing.Size(982, 463);
            this.Controls.Add(this.acceptbtn);
            this.Controls.Add(this.recieptslbl);
            this.Controls.Add(this.paymentlbl);
            this.Controls.Add(this.fantas);
            this.Controls.Add(this.sprite);
            this.Controls.Add(this.colas);
            this.Controls.Add(this.waterb);
            this.Controls.Add(this.canadadd);
            this.Controls.Add(this.hotdog);
            this.Controls.Add(this.fries);
            this.Controls.Add(this.cheeseb);
            this.Controls.Add(this.hamburger);
            this.Controls.Add(this.headerpnl);
            this.Font = new System.Drawing.Font("Yu Gothic Light", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ForeColor = System.Drawing.SystemColors.Menu;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Opacity = 0.98D;
            this.Text = "BRGRS-SHOP";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.headerpnl.ResumeLayout(false);
            this.headerpnl.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel headerpnl;
        private System.Windows.Forms.Label exitlbl;
        private System.Windows.Forms.Label headerlink;
        private System.Windows.Forms.Panel headerlogo;
        private System.Windows.Forms.Panel hamburger;
        private System.Windows.Forms.Panel cheeseb;
        private System.Windows.Forms.Panel fries;
        private System.Windows.Forms.Panel hotdog;
        private System.Windows.Forms.Panel canadadd;
        private System.Windows.Forms.Panel waterb;
        private System.Windows.Forms.Panel colas;
        private System.Windows.Forms.Panel sprite;
        private System.Windows.Forms.Panel fantas;
        private System.Windows.Forms.Label paymentlbl;
        private System.Windows.Forms.Label recieptslbl;
        private System.Windows.Forms.Button acceptbtn;
    }
}


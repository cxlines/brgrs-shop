﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace brgrs_shop
{
    public partial class Form1 : Form
    {

    //BRGR'S - SHOP .NET APPLICATION Developed by Stefan Müller
    //For Community and Educational (mostly for beginners in C# .NET)
    //be the best.
        public Form1()
        {
            InitializeComponent();
        }

        //messages in MesageBox
        private string exitmsg = "Thank you for using BRGRS-SHOP Application. \nDeveloped by Stefan Müller \nfor community and educational use.";
        private string exportmsg = "Reciept Exported! \nHave a nice day! \n@codeatn8";
        //headerlink - link opening - developers links
        private string headerlinks = "https://www.instagram.com/codeatn8";
        //Prices (individually) ; letter "p" stands for price
        double payments = 0.00;
        double hamb = 1.70;
        double cheesb = 1.80;
        double hotdogp = 1.50;
        double friesp = 1.20;
        double bwater = 1.50;
        double canadadp = 1.80;
        double colap = 1.80;
        double spritep = 1.80;
        double fantap = 1.80;
        //limit for accepting a payment
        double limitprice = 1.20;

        private void paymentchecking() {
            //Acceptable payment needs to be grater than limitprice or equal
            if (payments > limitprice)
            {
                acceptbtn.Enabled = true;
                acceptbtn.Visible = true;
                acceptbtn.BackColor = Color.LightGreen;
                acceptbtn.ForeColor = Color.Black;
            }
            else
            {
                acceptbtn.Enabled = false;
                acceptbtn.Visible = false;
            }
        }
        private void newreciept() {

                //Accepted - Reset the price
                payments = 0.00;
                //Accepted - Reset the Payment Label
                paymentlbl.Text = "$ " + payments;
        }
        private void exportreciept() {
            //Exporting the reciept after clicking Accept (for payment)
            //Reciept exported in C:\\ as brgrs_reciept
            TextWriter brgrs_reciept = new StreamWriter("C:\\brgrsreciept.txt");
            brgrs_reciept.Write(recieptslbl);
            brgrs_reciept.Close();
        }
        
        private void exitlbl_Click(object sender, EventArgs e)
        {
            //Message before exit
            MessageBox.Show(exitmsg, "Exit →", MessageBoxButtons.OK);
            //Exit from application
            this.Close();
        }

        private void headerlink_Click(object sender, EventArgs e)
        {
            //Link for the "restaurant" for ex: online ordering, price list.
            //Used in headerlogo.
            System.Diagnostics.Process.Start(headerlinks);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Starting up
            paymentlbl.Text = "$" + payments;
            recieptslbl.Text = string.Empty;
        }

        private void hamburger_Click(object sender, EventArgs e)
        {
            payments += hamb;
            paymentlbl.Text = "$" + payments;
            recieptslbl.Text += "\n○ Hamburger $" + hamb;
            paymentchecking();
        }

        private void cheeseb_Click(object sender, EventArgs e)
        {
            payments += cheesb;
            paymentlbl.Text = "$" + payments;
            recieptslbl.Text += "\n○ Cheesburger $" + cheesb;
            paymentchecking();
        }

        private void fries_Click(object sender, EventArgs e)
        {
            payments += friesp;
            paymentlbl.Text = "$" + payments;
            recieptslbl.Text += "\n○ Fries $" + friesp;
            paymentchecking();
        }

        private void hotdog_Click(object sender, EventArgs e)
        {
            payments += hotdogp;
            paymentlbl.Text = "$" + payments;
            recieptslbl.Text += "\n○ HotDog $" + hotdogp;
            paymentchecking();
        }

        private void canadadd_Click(object sender, EventArgs e)
        {
            payments += canadadp;
            paymentlbl.Text = "$" + payments;
            recieptslbl.Text += "\n○ CanadaDry $" + canadadp;
            paymentchecking();
        }

        private void waterb_Click(object sender, EventArgs e)
        {
            payments += bwater;
            paymentlbl.Text = "$" + payments;
            recieptslbl.Text += "\n○ Water (bottle) $" + bwater;
            paymentchecking();
        }

        private void colas_Click(object sender, EventArgs e)
        {
            payments += colap;
            paymentlbl.Text = "$" + payments;
            recieptslbl.Text += "\n○ CocaCola $" + colap;
            paymentchecking();
        }

        private void sprite_Click(object sender, EventArgs e)
        {
            payments += spritep;
            paymentlbl.Text = "$" + payments;
            recieptslbl.Text += "\n○ Sprite $" + spritep;
            paymentchecking();
        }

        private void fantas_Click(object sender, EventArgs e)
        {
            payments += fantap;
            paymentlbl.Text = "$" + payments;
            recieptslbl.Text += "\n○ Fanta $" + fantap;
            paymentchecking();
        }

        private void acceptbtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show(exportmsg, "Payment Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            exportreciept();
            newreciept();
        }
    }
}
